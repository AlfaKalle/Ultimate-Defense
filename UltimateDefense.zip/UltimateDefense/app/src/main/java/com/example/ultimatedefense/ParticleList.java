package com.example.ultimatedefense;

public class ParticleList {

    public ParticleChain first;

    public ParticleList()
    {
        first = null;
    }

    void AddParticle(BasicParticle p)
    {
        ParticleChain np = new ParticleChain();
        np.p = p;
        np.next = this.first;

        this.first = np;
    }

}
