package com.example.ultimatedefense;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;

public class AudioHelper {

    private static SoundPool soundPool;

    private static AudioManager audioManager;
    private static final int MAX_STREAMS = 5;
    private static final int streamType = AudioManager.STREAM_MUSIC;

    private static boolean loaded;

    public static int soundIdDestroy;
    public static int soundIdGun1;
    public static int soundIdGun2;
    public static int soundIdHurt;

    public static int soundIdIntro;
    private static float volume;

    public static void Init(Context context)
    {
        audioManager = (AudioManager) context.getSystemService(context.AUDIO_SERVICE);

        int streamType = 0;
        float currentVolumeIndex = (float) audioManager.getStreamVolume(streamType);

        float maxVolumeIndex  = (float) audioManager.getStreamMaxVolume(streamType);

        volume = currentVolumeIndex / maxVolumeIndex;


        // For Android SDK >= 21
        if (Build.VERSION.SDK_INT >= 21 ) {
            AudioAttributes audioAttrib = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();

            SoundPool.Builder builder= new SoundPool.Builder();
            builder.setAudioAttributes(audioAttrib).setMaxStreams(MAX_STREAMS);

            soundPool = builder.build();
        }
        // for Android SDK < 21
        else {
            // SoundPool(int maxStreams, int streamType, int srcQuality)
            soundPool = new SoundPool(MAX_STREAMS, AudioManager.STREAM_MUSIC, 0);
        }

        soundPool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
            @Override
            public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
                loaded = true;
            }
        });

        soundIdDestroy = soundPool.load(context, R.raw.death1,1);

        soundIdGun1 = soundPool.load(context, R.raw.gun1,1);

        soundIdGun2 = soundPool.load(context, R.raw.gun2,1);

        soundIdHurt = soundPool.load(context, R.raw.hurt,1);

        soundIdIntro = soundPool.load(context, R.raw.intro,1);
    }

    public static void Play(int id)
    {
        soundPool.play(id, volume, volume, 1, 0, 1f);
    }

}
