package com.example.ultimatedefense;

public class Point2D {

    public Point2D()
    {
        x = y = 0.0f;
    }
    public Point2D(float xp, float yp)
    {
        x = xp;
        y = yp;
    }

    public float x, y;

}
