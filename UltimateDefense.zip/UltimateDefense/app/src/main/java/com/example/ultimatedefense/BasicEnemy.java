package com.example.ultimatedefense;

import android.graphics.Canvas;
import android.graphics.Paint;

public class BasicEnemy extends BasicParticle {

    public BasicParticle [] arms;

    public BasicEnemy(float cx, float cy, float xdir, float ydir, float rad, Paint bColor)
    {
        x = cx;
        y = cy;
        xd = xdir;
        yd = ydir;
        radius = rad;
        color = bColor;

        arms = new BasicParticle[2];

        float t = (float) Math.sqrt(xd * xd + yd * yd);

        arms[0] = new BasicParticle(x + -yd / t * radius * 1.2f, y + xd / t * radius * 1.2f, radius * 0.3f,
        bColor);
        arms[1] = new BasicParticle(x + yd / t * radius * 1.2f, y + -xd / t * radius * 1.2f, radius * 0.3f,
                bColor);

    }

    @Override
    public void update()
    {
        float speed = 0.005f;

        x += xd * speed;
        y += yd * speed;

        arms[0].x += xd * speed;
        arms[0].y += yd * speed;
        arms[1].x += xd * speed;
        arms[1].y += yd * speed;
    }

    @Override
    public void draw(Canvas canvas)
    {
        canvas.drawCircle(x, y, radius, color);

        arms[0].draw(canvas);
        arms[1].draw(canvas);

    }

}
