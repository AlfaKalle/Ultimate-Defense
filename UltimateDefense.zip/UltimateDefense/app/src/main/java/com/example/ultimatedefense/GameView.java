package com.example.ultimatedefense;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.view.MotionEvent;
import android.view.SurfaceHolder;

import java.util.Random;

public class GameView extends android.view.SurfaceView implements SurfaceHolder.Callback {
    private MainThread thread;

    private Context mainContext;

    private float screenWidth;
    private float screenHeight;

    private float halfSWidth;
    private float halfSHeight;

    private Drawable bg;

    private Drawable introPic;

    private Drawable gunChangePic;
    private Drawable grenadePic;
    private Drawable shootPic;
    private Drawable turnLeftPic;
    private Drawable turnRightPic;

    private GameState gameState = GameState.INTRO;

    private BasicParticle player;
    private BasicParticle playerTip;
    private float boxTipAngle = 0.0f;
    private float btAngleSpeed = 0.0f;
    private int playerHP = 100;
    private int playerAmmo = 1000;

    private int score = 0;

    private int shootTimer = 0;

    private ParticleList bulletList;

    private ParticleList enemyList;

    private ParticleList decalsList = new ParticleList();

    private int rayTimer = 0;

    private float x1, y1, x2, y2;

    boolean turnLeftBDown = false;
    boolean turnRightBDown = false;
    boolean shootBDown = false;
    boolean changeDown = false;
    boolean grenadeBDown = false;

    private int grenadeCharge = 0;

    ParticleList grenadeList = new ParticleList();

    private int chosenWeapon = 1;  // 1 = bubble gun, 2 = pistol;

    private Activity mainActivity;

    private static MediaPlayer mediaPlayer;

    public GameView(Activity appActivity, Context context) {
        super(context);
        mainContext = context;
        mainActivity = appActivity;

        getHolder().addCallback(this);

        thread = new MainThread(getHolder(), this);
        setFocusable(true);

        setSystemUiVisibility(SYSTEM_UI_FLAG_HIDE_NAVIGATION | SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        screenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
        screenHeight = Resources.getSystem().getDisplayMetrics().heightPixels;

        halfSWidth = screenWidth * 0.5f;
        halfSHeight = screenHeight * 0.5f;

        bg = getResources().getDrawable(R.drawable.bg, null);
        bg.setBounds(0, 0, (int)screenWidth, (int)screenHeight);

        introPic = getResources().getDrawable(R.drawable.ak, null);
        introPic.setBounds((int) (screenWidth * 0.5f - 180.0f), 0, (int) (screenWidth * 0.5f + 180.0f), 500);

        gunChangePic = getResources().getDrawable(R.drawable.change, null);
        gunChangePic.setBounds((int) (screenWidth * 0.275f), (int) (screenHeight * 0.92f), (int) (screenWidth * 0.375f), (int)screenHeight);

        grenadePic = getResources().getDrawable(R.drawable.grenade, null);
        grenadePic.setBounds((int) (screenWidth * 0.45f), (int) (screenHeight * 0.92f), (int) (screenWidth * 0.55f), (int)screenHeight);

        shootPic = getResources().getDrawable(R.drawable.shoot, null);
        shootPic.setBounds((int) (screenWidth * 0.625f), (int) (screenHeight * 0.92f), (int) (screenWidth * 0.725f), (int)screenHeight);

        turnLeftPic = getResources().getDrawable(R.drawable.lturn, null);
        turnLeftPic.setBounds((int) (screenWidth * 0.0), (int) (screenHeight * 0.92f), (int) (screenWidth * 0.175f), (int)screenHeight);

        turnRightPic = getResources().getDrawable(R.drawable.rturn, null);
        turnRightPic.setBounds((int) (screenWidth * 0.825f), (int) (screenHeight * 0.92f), (int) (screenWidth * 1.0f), (int)screenHeight);

        Paint color = new Paint();
        color.setColor(Color.rgb(0, 0, 255));
        player = new BasicParticle(0.0f, 0.0f,
                0.075f, color);

        Paint tColor = new Paint();
        tColor.setColor(Color.rgb(128, 128, 196));
        playerTip = new BasicParticle(0.0f, 0.0f - player.radius * 1.25f,
                0.0375f, tColor);

        bulletList = new ParticleList();

        enemyList = new ParticleList();

        for(int i = 0; i < 20; i++)
        {
            Paint p = new Paint();
            p.setColor(Color.CYAN);

            Random r = new Random();
            float rdir = (float) (r.nextFloat() * Math.PI * 2.0);
            float dist = (float)r.nextInt(5);

            if(rdir < Math.PI)
            {
                float cdist = (float) (1.0 - (Math.abs(rdir - Math.PI * 0.5) / (Math.PI * 0.5)));
                dist = (float) (Math.sqrt(cdist) * dist + 0.5f);
            }
            else
            {
                float cdist = (float) (1.0 - (Math.abs(rdir - Math.PI * 1.5f) / (Math.PI * 0.5f)));
                dist = (float) (Math.sqrt(cdist) * dist + 0.5f);
            }

            float xd = (float) Math.sin(rdir);
            float yd = (float) Math.cos(rdir);

            BasicEnemy bp = new BasicEnemy(xd * dist, yd * dist, -xd, -yd, 0.05f, p);

            enemyList.AddParticle(bp);
        }

        AudioHelper.Init(mainContext);
    }

    public void update() {

        switch(gameState)
        {
            case INTRO:
                break;
            case MENU:
                break;
            case GAME:
                if (turnLeftBDown) {
                    btAngleSpeed -= Math.PI / 360.0f;
                }

                if (turnRightBDown) {
                    btAngleSpeed += Math.PI / 360.0f;
                }

                boxTipAngle += btAngleSpeed;
                btAngleSpeed *= 0.95f;
                playerTip.x = (float) (Math.sin(boxTipAngle) * player.radius * 1.25f);
                playerTip.y = (float) (Math.cos(boxTipAngle) * player.radius * -1.25f);

                ParticleChain f = bulletList.first;
                ParticleChain prev = null;
                while (f != null) {
                    boolean removeBullet = false;

                    f.p.x += f.p.xd * 0.01f;
                    f.p.y += f.p.yd * 0.01f;

                    float xdist = f.p.x;
                    float ydist = f.p.y;

                    float dist = xdist * xdist + ydist * ydist;

                    // remove too far away gotten bullets from list
                    if (dist > 500.0f) {
                        removeBullet = true;
                    }

                    ParticleChain fEnemy = enemyList.first;
                    ParticleChain prevEnemy = null;

                    while (fEnemy != null) {

                        float xd = fEnemy.p.x - f.p.x;
                        float yd = fEnemy.p.y - f.p.y;

                        float cdist = xd * xd + yd * yd;

                        if (cdist < fEnemy.p.radius * fEnemy.p.radius + f.p.radius * f.p.radius) {
                            removeBullet = true;

                            score++;

                            AudioHelper.Play(AudioHelper.soundIdDestroy);

                            DecalHelper.addBloodDecals(fEnemy.p.x, fEnemy.p.y, decalsList);

                            if (prevEnemy != null) {
                                prevEnemy.next = fEnemy.next;
                                fEnemy = fEnemy.next;
                            } else {
                                enemyList.first = fEnemy.next;
                                fEnemy = fEnemy.next;
                            }
                        } else {
                            prevEnemy = fEnemy;
                            fEnemy = fEnemy.next;
                        }

                    }

                    if (removeBullet) {
                        if (prev != null) {
                            prev.next = f.next;
                            f = f.next;
                        } else {
                            bulletList.first = f.next;
                            f = f.next;
                        }
                    } else {
                        prev = f;
                        f = f.next;
                    }
                }

                if (shootBDown && playerAmmo > 0 && shootTimer == 0) {

                    switch(chosenWeapon) {

                        case 1:

                            Paint p = new Paint();
                            p.setColor(Color.YELLOW);
                            BasicParticle bp = new BasicParticle(playerTip.x, playerTip.y, 0.02f, p);
                            bp.xd = (float) (Math.sin(boxTipAngle) * 1.0);
                            bp.yd = (float) (Math.cos(boxTipAngle) * -1.0f);

                            bulletList.AddParticle(bp);

                            AudioHelper.Play(AudioHelper.soundIdGun1);

                            break;

                        case 2:

                            ParticleChain fEnemy = enemyList.first;
                            ParticleChain prevEnemy = null;

                            ParticleChain hit = null;
                            ParticleChain beforeHitted = null;

                            Point2D cp = new Point2D(player.x, player.y);
                            Point2D shootd = new Point2D((float) (Math.sin(boxTipAngle) * 1.0), (float) (Math.cos(boxTipAngle) * -1.0f));
                            float dist = 1000000.0f;

                            x1 = player.x + shootd.x * player.radius * 1.25f;
                            y1 = player.y + shootd.y * player.radius * 1.25f;
                            x2 = player.x + shootd.x * 1000.0f;
                            y2 = player.y + shootd.y * 1000.0f;
                            rayTimer = 4;

                            AudioHelper.Play(AudioHelper.soundIdGun2);

                            while (fEnemy != null) {

                                Point2D ep = new Point2D(fEnemy.p.x, fEnemy.p.y);

                                float td = Helper.IntersectRaySphere(cp, shootd, ep, fEnemy.p.radius);

                                if(td < dist)
                                {
                                    beforeHitted = prevEnemy;
                                    hit = fEnemy;
                                    dist = td;
                                }

                                prevEnemy = fEnemy;
                                fEnemy = fEnemy.next;

                            }

                            DecalHelper.addFireDecals(cp.x + shootd.x * player.radius * 1.25f, cp.y + shootd.y * player.radius * 1.25f, shootd.x, shootd.y, decalsList);

                            if(hit != null)
                            {
                                score++;

                                AudioHelper.Play(AudioHelper.soundIdDestroy);

                                DecalHelper.addBloodDecals(hit.p.x, hit.p.y, decalsList);

                                x2 = player.x + shootd.x * dist;
                                y2 = player.y + shootd.y * dist;

                                if(beforeHitted == null)
                                {
                                    enemyList.first = hit.next;
                                }
                                else
                                {
                                    beforeHitted.next = hit.next;
                                }
                            }

                            break;

                        default:
                            break;
                    }

                    playerAmmo--;
                    shootTimer = 5;
                }

                ParticleChain fEnemy = enemyList.first;
                ParticleChain prevEnemy = null;

                while (fEnemy != null) {

                    float xd = fEnemy.p.x;
                    float yd = fEnemy.p.y;

                    float dist = xd * xd + yd * yd;

                    if (dist < player.radius * player.radius + fEnemy.p.radius * fEnemy.p.radius) {
                        playerHP -= 10;

                        DecalHelper.addBloodDecals(player.x, player.y, decalsList);

                        AudioHelper.Play(AudioHelper.soundIdHurt);

                        if (prevEnemy != null) {
                            prevEnemy.next = fEnemy.next;
                            fEnemy = fEnemy.next;
                        } else {
                            enemyList.first = fEnemy.next;
                            fEnemy = fEnemy.next;
                        }
                    }
                    else {
                        prevEnemy = fEnemy;
                        fEnemy = fEnemy.next;
                    }

                }

                ParticleChain fDecal = decalsList.first;
                ParticleChain prevDecal = null;

                while(fDecal != null)
                {
                    fDecal.p.timer--;

                    fDecal.p.x += fDecal.p.xd * 0.01f;
                    fDecal.p.y += fDecal.p.yd * 0.01f;

                    if(fDecal.p.timer <= 0)
                    {
                        if (prevDecal != null) {
                            prevDecal.next = fDecal.next;
                            fDecal = fDecal.next;
                        } else {
                            decalsList.first = fDecal.next;
                            fDecal = fDecal.next;
                        }
                    }
                    else {
                        prevDecal = fDecal;
                        fDecal = fDecal.next;
                    }
                }

                ParticleChain fGrenade = grenadeList.first;
                ParticleChain prevGrenade = null;

                while(fGrenade != null)
                {
                    Grenade g = (Grenade) fGrenade.p;

                    fGrenade.p.timer--;

                    fGrenade.p.x += fGrenade.p.xd * g.speed;
                    fGrenade.p.y += fGrenade.p.yd * g.speed;

                    if(fGrenade.p.timer <= 0)
                    {
                        fEnemy = enemyList.first;
                        prevEnemy = null;

                        Point2D p2 = new Point2D(fGrenade.p.x, fGrenade.p.y);

                        while (fEnemy != null) {

                            float cdist = Helper.IntersectSphereSphere(new Point2D(fEnemy.p.x, fEnemy.p.y), p2, fEnemy.p.radius, 0.15f);

                            if (cdist < Float.MAX_VALUE) {

                                score++;

                                AudioHelper.Play(AudioHelper.soundIdDestroy);

                                DecalHelper.addBloodDecals(fEnemy.p.x, fEnemy.p.y, decalsList);

                                if (prevEnemy != null) {
                                    prevEnemy.next = fEnemy.next;
                                    fEnemy = fEnemy.next;
                                } else {
                                    enemyList.first = fEnemy.next;
                                    fEnemy = fEnemy.next;
                                }
                            } else {
                                prevEnemy = fEnemy;
                                fEnemy = fEnemy.next;
                            }

                        }

                        DecalHelper.addGrenadeExplodeDecals(fGrenade.p.x, fGrenade.p.y, decalsList);

                        if (prevGrenade != null) {
                            prevGrenade.next = fGrenade.next;
                            fGrenade = fGrenade.next;
                        } else {
                            grenadeList.first = fGrenade.next;
                            fGrenade = fGrenade.next;
                        }
                    }
                    else {
                        prevGrenade = fGrenade;
                        fGrenade = fGrenade.next;
                    }
                }

                if (shootTimer > 0) shootTimer--;

                if(rayTimer > 0) rayTimer--;

                if(grenadeBDown)
                {
                    if(grenadeCharge < 60)
                    {
                        grenadeCharge++;
                    }
                    else
                    {
                        grenadeCharge = 0;
                        grenadeBDown = false;
                    }
                }
                else if(grenadeCharge > 0) // throw charged grenade
                {
                    Paint p = new Paint();
                    p.setColor(Color.RED);
                    Grenade bp = new Grenade(playerTip.x, playerTip.y, 0.02f, p, 31 - grenadeCharge);
                    bp.xd = (float) (Math.sin(boxTipAngle) * 1.0);
                    bp.yd = (float) (Math.cos(boxTipAngle) * -1.0f);
                    bp.speed = 0.0025f + 0.002f * grenadeCharge;

                    grenadeList.AddParticle(bp);

                    grenadeCharge = 0;
                }

                if(playerHP <= 0 || enemyList.first == null) gameState = GameState.END;

                break;

            case END:

                break;

        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        switch(gameState) {
            case INTRO:
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    if (event.getX() >= screenWidth * 0.05f && event.getX() < screenWidth * 0.95f &&
                            event.getY() >= screenHeight * 0.7f && event.getY() <= screenHeight * 0.8f)
                    {
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.youtube.com/watch?v=lvMvjucXyeU"));
                        mainContext.startActivity(browserIntent);
                        gameState = GameState.MENU;
                    }
                    else
                    {
                        gameState = GameState.MENU;
                    }
                //    AudioHelper.Play(AudioHelper.soundIdIntro);
                    mediaPlayer = MediaPlayer.create(mainContext, R.raw.intro);
                    mediaPlayer.start();
                }
                break;
            case MENU:
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    gameState = GameState.GAME;
                }
                break;
            case GAME:
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    if (event.getX() >= 0.0f && event.getX() <= 0.175f * screenWidth &&
                            event.getY() >= screenHeight * 0.9f && event.getY() <= screenHeight) {
                        turnLeftBDown = true;
                    }
                    if (event.getX() >= screenWidth * 0.825f && event.getX() <= screenWidth &&
                            event.getY() >= screenHeight * 0.9f && event.getY() <= screenHeight) {
                        turnRightBDown = true;
                    }
                    if (event.getX() >= screenWidth * 0.225f && event.getX() <= screenWidth * 0.375f &&
                            event.getY() >= screenHeight * 0.9f && event.getY() <= screenHeight) {
                        if(chosenWeapon == 2) chosenWeapon = 1;
                        else if(chosenWeapon == 1) chosenWeapon = 2;
                        else chosenWeapon = 1;

                        changeDown = true;
                    }
                    if (event.getX() >= screenWidth * 0.625f && event.getX() <= screenWidth * 0.775f &&
                            event.getY() >= screenHeight * 0.9f && event.getY() <= screenHeight) {
                        shootBDown = true;
                    }
                    if (event.getX() >= screenWidth * 0.45f && event.getX() <= screenWidth * 0.55f &&
                            event.getY() >= screenHeight * 0.9f && event.getY() <= screenHeight) {
                        grenadeBDown = true;
                    }
                }
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    turnLeftBDown = false;
                    turnRightBDown = false;
                    shootBDown = false;
                    changeDown = false;
                    grenadeBDown = false;
                }

                break;

            case END:

                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    mainActivity.finish();
                }

                break;
        }

        return true;
    }

    public void drawParticle(Canvas canvas, BasicParticle p)
    {
        canvas.drawCircle(p.x * halfSWidth + halfSWidth, p.y * halfSWidth + halfSHeight, p.radius * halfSWidth, p.color);
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        thread.setRunning(true);
        thread.start();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {

        boolean retry = true;
        while (retry) {
            try {
                thread.setRunning(false);
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            retry = false;
        }
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);

        Rect bounds = new Rect();
        Paint p = new Paint();

        if (canvas != null) {
            switch(gameState) {
                case INTRO:
                    introPic.setBounds((int) (screenWidth * 0.275), 0, (int) (screenWidth * 0.725f), (int) (screenHeight * 0.5f));
                    introPic.draw(canvas);

                    p.setColor(Color.BLUE);
                    p.setTextSize(50 / 360.0f * halfSWidth);
                    String t = "A game by AlfaKalle";
                    p.getTextBounds(t,0, t.length(), bounds);
                    canvas.drawText(t, screenWidth * 0.5f - bounds.width() * 0.5f, screenHeight * 0.6f, p);

                    p.setColor(Color.WHITE);
                    canvas.drawRect(screenWidth * 0.05f, screenHeight * 0.7f, screenWidth * 0.95f, screenHeight * 0.8f, p);

                    p.setColor(Color.GREEN);
                    p.setTextSize(40 / 360.0f * halfSWidth);
                    p.setFakeBoldText(true);
                    t = "Press here to open AlfaKalle song!";
                    p.getTextBounds(t,0, t.length(), bounds);
                    canvas.drawText(t, screenWidth * 0.5f - bounds.width() * 0.5f, screenHeight * 0.76f, p);

                    break;

                case MENU:
                    introPic.setBounds((int) (screenWidth * 0.8), 0, (int) (screenWidth), (int) (screenHeight * 0.25f));
                    introPic.draw(canvas);

                    introPic.setBounds(0, 0, (int) (screenWidth * 0.2f), (int) (screenHeight * 0.25f));
                    introPic.draw(canvas);

                    p.setColor(Color.BLUE);
                    p.setTextSize(50 / 360.0f * halfSWidth);
                    t = "Press screen to start";
                    p.getTextBounds(t,0, t.length(), bounds);
                    canvas.drawText(t, screenWidth * 0.5f - bounds.width() * 0.5f, screenHeight * 0.6f, p);

                    p.setColor(Color.MAGENTA);
                    p.setTextSize(60 / 360.0f * halfSWidth);
                    t = "Ultimate";
                    p.getTextBounds(t,0, t.length(), bounds);
                    canvas.drawText(t, screenWidth * 0.5f - bounds.width() * 0.5f, screenHeight * 0.1f, p);

                    t = "Defense";
                    p.getTextBounds(t,0, t.length(), bounds);
                    canvas.drawText(t, screenWidth * 0.5f - bounds.width() * 0.5f, screenHeight * 0.2f, p);

                    break;
                case GAME:

                    bg.draw(canvas);
                    canvas.drawCircle(player.x * halfSWidth + halfSWidth, player.y * halfSWidth + halfSHeight, player.radius * halfSWidth, player.color);
                    canvas.drawCircle(playerTip.x * halfSWidth + halfSWidth, playerTip.y * halfSWidth + halfSHeight, playerTip.radius * halfSWidth, playerTip.color);

                    ParticleChain f = bulletList.first;
                    while (f != null) {
                        drawParticle(canvas, f.p);
                        f = f.next;
                    }

                    f = enemyList.first;
                    while (f != null) {
                        f.p.update();
                        BasicEnemy e = (BasicEnemy) f.p;
                        drawParticle(canvas, e);
                        drawParticle(canvas, e.arms[0]);
                        drawParticle(canvas, e.arms[1]);
                        f = f.next;
                    }

                    f = decalsList.first;
                    while (f != null) {
                        drawParticle(canvas, f.p);
                        f = f.next;
                    }

                    f = grenadeList.first;
                    while (f != null) {
                        drawParticle(canvas, f.p);
                        f = f.next;
                    }

                    p = new Paint();
                    p.setColor(Color.rgb(255, 255, 0));

                    if(rayTimer > 0)
                    {
                        canvas.drawLine(x1 * halfSWidth + halfSWidth, y1 * halfSWidth + halfSHeight, x2 * halfSWidth + halfSWidth, y2 * halfSWidth + halfSHeight, p);
                    }

                    p.setColor(Color.rgb(255, 0, 255));
                    if (turnLeftBDown) turnLeftPic.setAlpha(110);
                    else turnLeftPic.setAlpha(255);;

                    turnLeftPic.draw(canvas);

                    if (turnRightBDown) turnRightPic.setAlpha(110);
                    else turnRightPic.setAlpha(255);

                    turnRightPic.draw(canvas);

                    if (changeDown) gunChangePic.setAlpha(110);
                    else gunChangePic.setAlpha(255);

                    gunChangePic.draw(canvas);

                    if (shootBDown) shootPic.setAlpha(110);
                    else shootPic.setAlpha(255);

                    shootPic.draw(canvas);

                    if(grenadeBDown) grenadePic.setAlpha(110);
                    else grenadePic.setAlpha(255);

                    grenadePic.draw(canvas);

                    p.setColor(Color.YELLOW);
                    p.setTextSize(40.0f / 360.0f * halfSWidth);
                    p.setFakeBoldText(true);
                    t = "Health " + Integer.toString(playerHP);
                    canvas.drawText(t, 10, 40 / 360.0f * halfSWidth, p);

                    t = "Ammo " + Integer.toString(playerAmmo);
                    canvas.drawText(t, 10, 90 / 360.0f * halfSWidth, p);

                    t = "Bubble gun";
                    p.getTextBounds(t,0, t.length(), bounds);
                    float mw = bounds.width() * 0.5f;

                    if(chosenWeapon == 1)
                    {
                        t = "Bubble gun";
                        p.getTextBounds(t,0, t.length(), bounds);
                        canvas.drawText(t, screenWidth - mw - bounds.width() * 0.5f , 40 / 360.0f * halfSWidth, p);
                    }
                    else {
                        t = "Zapper";
                        p.getTextBounds(t,0, t.length(), bounds);
                        canvas.drawText(t, screenWidth - mw - bounds.width() * 0.5f, 40 / 360.0f * halfSWidth, p);
                    }

                    p.setColor(Color.YELLOW);
                    canvas.drawRect(screenWidth * 0.9f, screenHeight * 0.1f, screenWidth * 0.9f + grenadeCharge * 1, screenHeight * 0.15f, p);

                    break;

                case END:

                    canvas.drawColor(Color.BLACK);

                    p.setColor(Color.BLUE);
                    p.setTextSize(40 / 360.0f * halfSWidth);
                    t = "Game Over!";
                    p.getTextBounds(t,0, t.length(), bounds);
                    canvas.drawText(t, screenWidth * 0.5f - bounds.width() * 0.5f, screenHeight * 0.5f - 50.0f, p);

                    t = "You scored " + Integer.toString(score);
                    p.getTextBounds(t,0, t.length(), bounds);
                    canvas.drawText(t, screenWidth * 0.5f - bounds.width() * 0.5f, screenHeight * 0.5f + 50.0f, p);

                    p.setColor(Color.GREEN);
                    t = "Press screen to continue";
                    p.getTextBounds(t,0, t.length(), bounds);
                    canvas.drawText(t, screenWidth * 0.5f - bounds.width() * 0.5f, screenHeight * 0.5f + 150.0f, p);

                    break;
            }
        }
    }
}
