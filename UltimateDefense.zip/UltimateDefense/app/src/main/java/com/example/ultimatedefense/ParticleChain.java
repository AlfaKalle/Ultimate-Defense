package com.example.ultimatedefense;

public class ParticleChain {
    public BasicParticle p;
    public ParticleChain next;


}
