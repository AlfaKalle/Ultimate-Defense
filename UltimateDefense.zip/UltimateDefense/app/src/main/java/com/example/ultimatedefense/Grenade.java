package com.example.ultimatedefense;

import android.graphics.Paint;

public class Grenade extends BasicParticle {

    public float speed;
    Grenade(float cx, float cy, float rad, Paint bColor, int t)
    {
        super(cx, cy, rad, bColor);
        timer = t;
        speed = 0.0f;
    }

}
