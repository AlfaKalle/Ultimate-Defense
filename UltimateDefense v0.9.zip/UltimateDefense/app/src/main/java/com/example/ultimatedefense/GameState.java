package com.example.ultimatedefense;

public enum GameState {
    INTRO, MENU, GAME, END
}
