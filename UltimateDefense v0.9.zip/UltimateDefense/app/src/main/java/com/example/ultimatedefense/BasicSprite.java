package com.example.ultimatedefense;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class BasicSprite {
    private Bitmap image;
    public float x, y;

    public BasicSprite(Bitmap bmp) {
        image = bmp;
        x = 0.0f;
        y = 0.0f;
    }

    public void draw(Canvas canvas) {
        canvas.drawBitmap(image, x, y, null);
    }
}