
package com.example.ultimatedefense;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class BasicParticle {

    public Paint color;
    public float radius;
    public float x, y;
    public float xd, yd;
    public int timer;

    public BasicParticle()
    {

    }

    public BasicParticle(float cx, float cy, float rad, Paint bColor) {
        x = cx;
        y = cy;
        xd = 0.0f;
        yd = 0.0f;
        radius = rad;
        color = bColor;
        timer = 0;
    }

    public void update()
    {

    }

    public void draw(Canvas canvas) {
        canvas.drawCircle(x, y, radius, color);
    }
}