package com.example.ultimatedefense;

import android.graphics.Color;
import android.graphics.Paint;

import java.util.Random;

public class DecalHelper {

    public static void addBloodDecals(float xp, float yp, ParticleList decalsList)
    {
        Random r = new Random();

        int count = r.nextInt(50) + 50;

        for(int i = 0; i < count; i++)
        {
            Paint p = new Paint();
            p.setColor(Color.RED);

            float rdir = (float) (r.nextFloat() * Math.PI * 2.0);
            float dist = (float)r.nextInt(10);

            float xd = (float) Math.sin(rdir);
            float yd = (float) Math.cos(rdir);

            BasicEnemy bp = new BasicEnemy(xp + xd * dist, yp + yd * dist, xd, yd, (r.nextInt(5) + 2) * 0.005f, p);
            bp.timer = 60;

            decalsList.AddParticle(bp);
        }
    }

    public static void addFireDecals(float xp, float yp, float xd, float yd, ParticleList decalsList)
    {
        Random r = new Random();

        int count = r.nextInt(5);

        for(int i = 0; i < count; i++)
        {
            Paint p = new Paint();
            p.setColor(Color.YELLOW);

            float rdir = (float) ((r.nextFloat() + 0.5f) * Math.PI * 0.5f);
            float dist = (float)r.nextInt(15) - 1.0f;

            float xdir = (float) Math.sin(rdir) * xd + (float) Math.cos(rdir) * -yd;
            float ydir = (float) Math.cos(rdir) * xd + (float) Math.sin(rdir) * yd;

            BasicEnemy bp = new BasicEnemy(xp + xdir * dist, yp + ydir * dist, xdir, ydir, (r.nextInt(3) + 2) * 0.005f, p);
            bp.timer = 15;

            decalsList.AddParticle(bp);
        }
    }

    public static void addGrenadeExplodeDecals(float xp, float yp, ParticleList grenadeDecalList)
    {
        Random r = new Random();

        int count = r.nextInt(15) + 5;

        for(int i = 0; i < count; i++)
        {
            Paint p = new Paint();
            p.setColor(Color.YELLOW);

            float rdir = (float) ((r.nextFloat() + 0.5f) * Math.PI * 2.0f);
            float dist = ((float)r.nextInt(15) + 1.0f) * 0.02f;

            float xdir = (float) Math.sin(rdir);
            float ydir = (float) Math.cos(rdir);

            BasicEnemy bp = new BasicEnemy(xp + xdir * dist, yp + ydir * dist, xdir, ydir, (r.nextInt(2) + 1) * 0.005f, p);
            bp.timer = 15;

            grenadeDecalList.AddParticle(bp);
        }
    }

}
