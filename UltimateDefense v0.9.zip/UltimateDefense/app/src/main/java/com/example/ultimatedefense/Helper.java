package com.example.ultimatedefense;

import android.graphics.Point;

import java.util.Vector;

public class Helper {

    public static float Dot(Point2D p1, Point2D p2)
    {
        return p1.x * p2.x + p1.y * p2.y;
    }

    public static float IntersectRaySphere(Point2D p, Point2D d, Point2D sc, float sr)
    {
        Point2D m = new Point2D();

        m.x = p.x - sc.x;
        m.y = p.y - sc.y;

        float b = Dot(m, d);
        float c = Dot(m, m) - sr * sr;

        // Exit if r’s origin outside s (c > 0) and r pointing away from s (b > 0)
        if (c > 0.0f && b > 0.0f) return Float.MAX_VALUE;
        float discr = b*b - c;

        // A negative discriminant corresponds to ray missing sphere
        if (discr < 0.0f) return Float.MAX_VALUE;

        // Ray now found to intersect sphere, compute smallest t value of intersection
        float t = (float) (-b - Math.sqrt(discr));

        // If t is negative, ray started inside sphere so clamp t to zero
        if (t < 0.0f) t = 0.0f;
        //    q = p + t * d;

        return t;
    }

    public static float IntersectSphereSphere(Point2D p1, Point2D p2, float rad1, float rad2)
    {
        float rdist = Float.MAX_VALUE;

        float x = p1.x - p2.x;
        float y = p1.y - p2.y;
        float colDist = x * x + y * y;

        if(colDist < rad1 * rad1 + rad2 * rad2) rdist = colDist;

        return rdist;
    }

}
